import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Activity, Shield, Wind, Smartphone, Eye, Clock, CheckCircle2, AlertTriangle, Cpu, Layers, Fingerprint, Zap, Lock, RotateCcw, Target, ShieldAlert, Radio, Sun, ThermometerSun, CloudFog, BellRing, HeartPulse} from 'lucide-react';
import { AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer } from 'recharts';

// --- 伪造的真实学习数据 (Mock Data) ---
const focusData = [
  { day: 'Mon', duration: 4.2, interruptions: 2 },
  { day: 'Tue', duration: 5.1, interruptions: 1 },
  { day: 'Wed', duration: 3.8, interruptions: 4 },
  { day: 'Thu', duration: 6.2, interruptions: 0 },
  { day: 'Fri', duration: 5.5, interruptions: 1 },
  { day: 'Sat', duration: 7.1, interruptions: 2 },
  { day: 'Sun', duration: 4.5, interruptions: 3 },
];

const envData = [
  { time: '09:00', co2: 450, temp: 22 },
  { time: '11:00', co2: 850, temp: 23 },
  { time: '13:00', co2: 1200, temp: 25 }, // 飙升点
  { time: '15:00', co2: 600, temp: 22 },  // 开窗后下降
  { time: '17:00', co2: 750, temp: 21 },
];

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const containerVariants = {
    hidden: { opacity: 0 },
    show: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 80, damping: 15 } }
  };

  return (
    <div className="min-h-screen relative selection:bg-sky-200 selection:text-sky-900 overflow-hidden font-sans">
      
      {/* --- 背景光效 --- */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <motion.div animate={{ x: [0, 30, 0], y: [0, -40, 0] }} transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }} className="absolute top-[-10%] left-[-5%] w-[600px] h-[600px] bg-sky-200/50 rounded-full mix-blend-multiply filter blur-[100px]" />
        <motion.div animate={{ x: [0, -30, 0], y: [0, 40, 0] }} transition={{ duration: 12, repeat: Infinity, ease: "easeInOut", delay: 1 }} className="absolute top-[20%] right-[-10%] w-[700px] h-[700px] bg-cyan-100/60 rounded-full mix-blend-multiply filter blur-[120px]" />
      </div>

      {/* --- 导航栏 --- */}
      <nav className="fixed top-0 w-full z-50 bg-white/40 backdrop-blur-2xl border-b border-white/60 shadow-[0_4px_30px_rgba(0,0,0,0.03)]">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-sky-400 to-blue-600 p-1.5 rounded-xl shadow-lg shadow-blue-200">
              <Activity className="text-white w-5 h-5" />
            </div>
            <span className="font-bold text-xl tracking-tight text-slate-800">FocusAura</span>
          </div>
          <div className="hidden md:flex space-x-1 border border-slate-200/50 bg-white/50 p-1 rounded-full shadow-inner">
            <NavTab active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')}>Overview</NavTab>
            <NavTab active={activeTab === 'zenlock'} onClick={() => setActiveTab('zenlock')}>ZenLock Details</NavTab>
            <NavTab active={activeTab === 'omnisense'} onClick={() => setActiveTab('omnisense')}>OmniSense Details</NavTab>
          </div>
          <div className="flex items-center gap-2 bg-emerald-50 rounded-full px-4 py-1.5 border border-emerald-100 shadow-sm">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
            <span className="text-xs font-semibold text-emerald-700 tracking-wide">M5StickC Live</span>
          </div>
        </div>
      </nav>

      {/* --- 主内容区 --- */}
      <main className="relative z-10 pt-28 px-6 pb-24 max-w-7xl mx-auto">
        
        {activeTab === 'dashboard' && (
          <motion.div variants={containerVariants} initial="hidden" animate="show">
            
            {/* 1. 顶部 Hero Slogan */}
            <motion.div variants={itemVariants} className="text-center mt-4 mb-16">
              <span className="inline-block py-1 px-3 rounded-full bg-blue-50 border border-blue-100 text-blue-600 text-sm font-semibold mb-4 shadow-sm">
                Session 2 · Group 7 · Hardware & Aura Team
              </span>
              <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight mb-4 text-slate-900 drop-shadow-sm">
                Master Your <span className="bg-clip-text text-transparent bg-gradient-to-r from-sky-500 to-blue-600">Attention.</span>
              </h1>
            </motion.div>

            {/* 2. 核心 KPI */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <KpiCard title="Focus Success Rate" value="88%" trend="+4.2%" trendUp={true} subtext="No phone pick-ups detected" icon={<Shield className="text-emerald-500" />} bgGradient="from-emerald-50 to-transparent" />
              <KpiCard title="Deep Work Duration" value="36h 25m" trend="+2.1h" trendUp={true} subtext="Weekly accumulated time" icon={<Clock className="text-blue-500" />} bgGradient="from-blue-50 to-transparent" />
              <KpiCard title="Health Interventions" value="12" trend="-3" trendUp={false} subtext="CO2 / Dark lighting alerts" icon={<Wind className="text-purple-500" />} bgGradient="from-purple-50 to-transparent" />
            </div>

            {/* 3. 全新模块：硬件生态中枢 (Hardware Ecosystem) */}
            <motion.div variants={itemVariants} className="mb-12">
              <h2 className="text-2xl font-bold text-slate-800 mb-6 flex items-center gap-2">
                <Cpu className="text-blue-500" /> Physical Hardware Ecosystem
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <HardwareCard 
                  unit="Weight I2C Unit" 
                  role="Physical Phone Jail" 
                  desc="Locks focus state. Detects if phone is removed (>150g)." 
                  icon={<Smartphone />} 
                  color="bg-sky-50 text-sky-600 border-sky-100" 
                />
                <HardwareCard 
                  unit="Mini ToF Radar" 
                  role="Spatial Anti-Escape" 
                  desc="Laser distance tracking (>80cm triggers Purple Alarm)." 
                  icon={<Activity />} 
                  color="bg-indigo-50 text-indigo-600 border-indigo-100" 
                />
                <HardwareCard 
                  unit="TVOC/eCO2 & ENV.III" 
                  role="Climate & Hypoxia Monitor" 
                  desc="Parallel tracking of CO2 (>1000ppm) and Temp extremes." 
                  icon={<Wind />} 
                  color="bg-teal-50 text-teal-600 border-teal-100" 
                />
                <HardwareCard 
                  unit="SK6812 RGB & Vibrator" 
                  role="Multi-sensory Feedback" 
                  desc="Visual timeline matrix & silent haptic alarms." 
                  icon={<Zap />} 
                  color="bg-amber-50 text-amber-600 border-amber-100" 
                />
              </div>
            </motion.div>

            {/* 4. 交互图表与遥测区 */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-12">
              
              {/* 左侧：实时遥测与硬件通讯状态 */}
              <motion.div variants={itemVariants} className="lg:col-span-1 glass-card p-6 rounded-3xl flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-center mb-6">
                    <h3 className="text-lg font-bold text-slate-800">I2C / Pb.Hub Telemetry</h3>
                    <span className="flex h-3 w-3 relative">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                    </span>
                  </div>
                  <div className="space-y-4">
                    <SensorRow name="Weight I2C" val="185g" status="Engaged" color="text-sky-600" bg="bg-sky-100" />
                    <SensorRow name="Mini ToF" val="450mm" status="User in seat" color="text-indigo-600" bg="bg-indigo-100" />
                    <SensorRow name="eCO2 (Hub CH1)" val="820ppm" status="Optimal" color="text-teal-600" bg="bg-teal-100" />
                    <SensorRow name="Unit Light (Pb.Hub)" val="650 Lux" status="Safe for eyes" color="text-amber-600" bg="bg-amber-100" />
                  </div>
                </div>
              </motion.div>

              {/* 右侧：Recharts 数据可视化 */}
              <motion.div variants={itemVariants} className="lg:col-span-2 space-y-6">
                
                {/* 专注时长柱状图 */}
                <div className="glass-card p-6 rounded-3xl h-[280px] flex flex-col">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-md font-bold text-slate-800">Weekly Focus Trends (Hours)</h3>
                  </div>
                  <div className="flex-1 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={focusData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                        <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} dy={10} />
                        <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                        <RechartsTooltip cursor={{fill: '#f1f5f9'}} contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}} />
                        <Bar dataKey="duration" fill="#3b82f6" radius={[6, 6, 0, 0]} barSize={32} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* 室内二氧化碳面积图 */}
                <div className="glass-card p-6 rounded-3xl h-[280px] flex flex-col">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-md font-bold text-slate-800">Room CO2 Levels (ppm)</h3>
                    <span className="text-xs font-semibold bg-red-50 text-red-500 px-2 py-1 rounded-full border border-red-100">Red/Blue Flash Intervention</span>
                  </div>
                  <div className="flex-1 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={envData}>
                        <defs>
                          <linearGradient id="colorCo2" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#14b8a6" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                        <XAxis dataKey="time" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} dy={10} />
                        <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
                        <RechartsTooltip contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}} />
                        <Area type="monotone" dataKey="co2" stroke="#14b8a6" strokeWidth={3} fillOpacity={1} fill="url(#colorCo2)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

              </motion.div>
            </div>

            {/* 5. 底层活动日志 */}
            <motion.div variants={itemVariants} className="glass-card p-6 rounded-3xl mb-10">
              <h3 className="text-lg font-bold text-slate-800 mb-6">Hardware Execution Log</h3>
              <div className="space-y-6">
                <TimelineItem time="14:55 PM" hardware="Unit Light -> Pb.Hub CH0" title="Darkness Eye-Care Triggered" desc="Illuminance dropped below 400 Lux. Sent digital pulse to Unit Vibrator for silent haptic alarm." type="warning" />
                <TimelineItem time="14:10 PM" hardware="Encoder -> I2C" title="Focus Session Initialized" desc="Rotary dial set to 25 mins. Button pressed. SK6812 LED strip entering visual countdown mode." type="success" />
                <TimelineItem time="13:45 PM" hardware="Mini ToF Radar" title="Desk Absence Detected" desc="Distance > 800mm. Screen color set to Purple. Away status logged." type="info" />
              </div>
            </motion.div>

          </motion.div>
        )}

        {activeTab !== 'dashboard' && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-20 text-center text-slate-400">
            Select Overview to see the Data Center.
          </motion.div>
        )}






        {/* --- ZenLock Engine 详情页 --- */}
        {activeTab === 'zenlock' && (
          <motion.div variants={containerVariants} initial="hidden" animate="show" className="mt-8">

            {/* 1. 页面专属头图区 (Hero) */}
            <motion.div variants={itemVariants} className="mb-16 flex flex-col md:flex-row items-center gap-10">
              <div className="flex-1">
                <div className="inline-flex items-center gap-2 py-1 px-3 rounded-full bg-indigo-50 border border-indigo-100 text-indigo-600 text-sm font-semibold mb-4 shadow-sm">
                  <Lock size={16} /> Core Module 01
                </div>
                <h1 className="text-5xl lg:text-6xl font-extrabold tracking-tight mb-4 text-slate-900 drop-shadow-sm">
                  ZenLock <span className="bg-clip-text text-transparent bg-gradient-to-r from-indigo-500 to-purple-600">Sentinel.</span>
                </h1>
                <p className="text-lg text-slate-500 font-medium leading-relaxed mb-6">
                  Digital discipline enforced by physical constraints. By requiring your device to be physically docked, we eliminate the temptation of screen-time at its root.
                </p>
              </div>
              
              {/* 右侧：炫酷的防沉迷雷达锁定 UI */}
              <div className="flex-1 w-full glass-card p-8 rounded-[3rem] border-4 border-white/60 relative overflow-hidden bg-gradient-to-br from-indigo-50/50 to-purple-50/50 shadow-xl shadow-indigo-100/50">
                 <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-200/50 rounded-full blur-3xl"></div>
                 <div className="relative z-10 flex flex-col items-center justify-center py-6">
                   <div className="relative flex items-center justify-center mb-6">
                     {/* 呼吸扫描圈特效 */}
                     <div className="absolute w-32 h-32 border-2 border-indigo-200 rounded-full animate-ping opacity-20"></div>
                     <div className="absolute w-24 h-24 border-2 border-indigo-300 rounded-full animate-ping opacity-40 animation-delay-500"></div>
                     <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-full shadow-lg shadow-indigo-200 flex items-center justify-center z-10 relative">
                       <Smartphone className="text-white w-8 h-8" />
                       {/* 右下角的锁定小绿标 */}
                       <div className="absolute -bottom-1 -right-1 bg-emerald-500 border-2 border-white rounded-full p-0.5">
                         <CheckCircle2 className="w-3 h-3 text-white" />
                       </div>
                     </div>
                   </div>
                   <h3 className="text-xl font-bold text-slate-800">Phone Jail Active</h3>
                   <p className="text-sm font-semibold text-indigo-500 mt-1">Payload: 185g (Verified)</p>
                 </div>
              </div>
            </motion.div>

            {/* 2. 硬件深度解析区 (The Arsenal) */}
            <motion.div variants={itemVariants} className="mb-16">
               <h2 className="text-2xl font-bold text-slate-800 mb-8 flex items-center gap-2">
                <Target className="text-purple-500" /> Component Breakdown
              </h2>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                 
                 {/* 硬件 1: Encoder */}
                 <div className="glass-card p-6 rounded-3xl group hover:-translate-y-1 transition-transform">
                   <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-600 flex items-center justify-center mb-4 group-hover:bg-indigo-100 group-hover:text-indigo-600 transition-colors">
                     <RotateCcw />
                   </div>
                   <h3 className="text-lg font-bold text-slate-800 mb-2">Tactile Encoder</h3>
                   <p className="text-sm text-slate-500 mb-4 h-16">Rotary dial for setting focus time. Provides physical confirmation, bypassing digital screens entirely.</p>
                   <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex justify-between items-center">
                     <span className="text-xs font-bold text-slate-400">Current Input</span>
                     <span className="text-sm font-bold text-indigo-600">25 mins</span>
                   </div>
                 </div>

                 {/* 硬件 2: Weight */}
                 <div className="glass-card p-6 rounded-3xl group border-indigo-100 shadow-[0_0_30px_rgba(99,102,241,0.08)] relative overflow-hidden">
                   <div className="absolute top-0 right-0 w-16 h-16 bg-indigo-500/10 rounded-bl-[100px]"></div>
                   <div className="w-12 h-12 rounded-2xl bg-indigo-100 text-indigo-600 flex items-center justify-center mb-4">
                     <Lock />
                   </div>
                   <h3 className="text-lg font-bold text-slate-800 mb-2">Weight I2C Unit</h3>
                   <p className="text-sm text-slate-500 mb-4 h-16">The core trigger. Continuously measures mass to ensure the device remains strictly docked.</p>
                   <div className="bg-white p-3 rounded-xl border border-indigo-50 flex justify-between items-center shadow-sm">
                     <span className="text-xs font-bold text-slate-400">Status</span>
                     <span className="text-sm font-bold text-emerald-500">&gt; 150g (Pass)</span>
                   </div>
                 </div>

                 {/* 硬件 3: ToF Radar */}
                 <div className="glass-card p-6 rounded-3xl group hover:-translate-y-1 transition-transform">
                   <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-600 flex items-center justify-center mb-4 group-hover:bg-purple-100 group-hover:text-purple-600 transition-colors">
                     <Radio />
                   </div>
                   <h3 className="text-lg font-bold text-slate-800 mb-2">Mini ToF Radar</h3>
                   <p className="text-sm text-slate-500 mb-4 h-16">Anti-cheat laser sensor. Scans presence to prevent leaving the phone docked while walking away.</p>
                   <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 flex justify-between items-center">
                     <span className="text-xs font-bold text-slate-400">User Distance</span>
                     <span className="text-sm font-bold text-purple-600">450mm (In Seat)</span>
                   </div>
                 </div>

              </div>
            </motion.div>

            {/* 3. 防作弊拦截数据面板 */}
             <motion.div variants={itemVariants} className="glass-card p-8 rounded-3xl mb-12 bg-gradient-to-r from-slate-50 to-indigo-50/30">
               <div className="flex justify-between items-center mb-8">
                  <h3 className="text-xl font-bold text-slate-800">Cheat Attempts Blocked</h3>
                  <div className="flex items-center gap-2 bg-amber-50 px-3 py-1 rounded-full border border-amber-100">
                     <ShieldAlert className="text-amber-500 w-4 h-4" />
                     <span className="text-xs font-bold text-amber-600">Strict Mode On</span>
                  </div>
               </div>
               
               <div className="flex flex-col md:flex-row gap-8 items-center">
                 <div className="text-center md:text-left">
                   <p className="text-6xl font-extrabold text-slate-800 mb-2 drop-shadow-sm">24</p>
                   <p className="text-sm font-semibold text-slate-500">Total interventions this week</p>
                 </div>
                 
                 <div className="flex-1 w-full bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex flex-col sm:flex-row items-center justify-around gap-4">
                    <div className="text-center flex-1">
                      <p className="text-3xl font-bold text-sky-500 mb-1">18</p>
                      <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Phone Pick-ups<br/>(Weight Drop)</p>
                    </div>
                    <div className="hidden sm:block w-px h-16 bg-slate-100"></div>
                    <div className="w-full h-px sm:hidden bg-slate-100"></div>
                    <div className="text-center flex-1">
                      <p className="text-3xl font-bold text-purple-500 mb-1">6</p>
                      <p className="text-xs font-bold uppercase tracking-wider text-slate-400">Seat Escapes<br/>(ToF &gt; 80cm)</p>
                    </div>
                 </div>
               </div>
             </motion.div>

          </motion.div>
        )}



        {/* --- OmniSense Guardian 详情页 --- */}
        {activeTab === 'omnisense' && (
          <motion.div variants={containerVariants} initial="hidden" animate="show" className="mt-8">

            {/* 1. 页面专属头图区 (Hero) */}
            <motion.div variants={itemVariants} className="mb-16 flex flex-col md:flex-row items-center gap-10">
              <div className="flex-1">
                <div className="inline-flex items-center gap-2 py-1 px-3 rounded-full bg-teal-50 border border-teal-100 text-teal-600 text-sm font-semibold mb-4 shadow-sm">
                  <HeartPulse size={16} /> Core Module 02
                </div>
                <h1 className="text-5xl lg:text-6xl font-extrabold tracking-tight mb-4 text-slate-900 drop-shadow-sm">
                  OmniSense <span className="bg-clip-text text-transparent bg-gradient-to-r from-teal-400 to-emerald-600">Guardian.</span>
                </h1>
                <p className="text-lg text-slate-500 font-medium leading-relaxed mb-6">
                  Physiological optimization for peak cognitive flow. We monitor the invisible factors—air quality, temperature, and lighting—so your brain never runs out of fuel.
                </p>
              </div>
              
              {/* 右侧：环境生态监测 UI */}
              <div className="flex-1 w-full glass-card p-8 rounded-[3rem] border-4 border-white/60 relative overflow-hidden bg-gradient-to-br from-teal-50/50 to-emerald-50/50 shadow-xl shadow-teal-100/50">
                 <div className="absolute top-0 left-0 w-40 h-40 bg-teal-200/40 rounded-full blur-3xl"></div>
                 <div className="relative z-10 flex flex-col items-center justify-center py-4">
                   <div className="relative flex items-center justify-center mb-6">
                     <div className="absolute w-36 h-36 border-2 border-dashed border-teal-300 rounded-full animate-[spin_20s_linear_infinite] opacity-60"></div>
                     <div className="absolute w-28 h-28 border border-emerald-200 rounded-full animate-pulse opacity-80"></div>
                     <div className="w-20 h-20 bg-gradient-to-br from-teal-400 to-emerald-500 rounded-full shadow-lg shadow-teal-200 flex items-center justify-center z-10 relative">
                       <CloudFog className="text-white w-10 h-10" />
                     </div>
                   </div>
                   <h3 className="text-xl font-bold text-slate-800">Environment Optimal</h3>
                   <div className="flex gap-4 mt-3">
                     <span className="text-sm font-semibold text-teal-600 flex items-center gap-1"><Wind size={14}/> 820 ppm</span>
                     <span className="text-sm font-semibold text-amber-500 flex items-center gap-1"><Sun size={14}/> 650 lx</span>
                   </div>
                 </div>
              </div>
            </motion.div>

            {/* 2. 环境传感器大解析 (Sensor Matrix) */}
            <motion.div variants={itemVariants} className="mb-16">
               <h2 className="text-2xl font-bold text-slate-800 mb-8 flex items-center gap-2">
                <Layers className="text-teal-500" /> Sensory Network
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                 
                 {/* 气味与缺氧雷达 */}
                 <div className="glass-card p-6 rounded-3xl group border-t-4 border-t-teal-400 hover:-translate-y-1 transition-transform">
                   <div className="flex justify-between items-start mb-4">
                     <div className="w-12 h-12 rounded-2xl bg-teal-100 text-teal-600 flex items-center justify-center">
                       <CloudFog />
                     </div>
                     <span className="bg-teal-50 text-teal-600 text-xs font-bold px-2 py-1 rounded-lg">I2C Port A</span>
                   </div>
                   <h3 className="text-lg font-bold text-slate-800 mb-2">TVOC/eCO2 Monitor</h3>
                   <p className="text-sm text-slate-500 mb-4 h-16">Detects CO2 spikes. If ppm &gt; 1000, triggers SK6812 LED strip to flash Red/Blue (Police Mode) forcing room ventilation.</p>
                 </div>

                 {/* 暗光护眼系统 */}
                 <div className="glass-card p-6 rounded-3xl group border-t-4 border-t-amber-400 hover:-translate-y-1 transition-transform">
                   <div className="flex justify-between items-start mb-4">
                     <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-600 flex items-center justify-center">
                       <Sun />
                     </div>
                     <span className="bg-amber-50 text-amber-600 text-xs font-bold px-2 py-1 rounded-lg">Pb.Hub CH0</span>
                   </div>
                   <h3 className="text-lg font-bold text-slate-800 mb-2">Unit Light & Vibrator</h3>
                   <p className="text-sm text-slate-500 mb-4 h-16">Darkness triggers the haptic alarm. When analog &lt; 500, pulses Unit Vibrator (CH1) silently to prompt turning on a desk lamp.</p>
                 </div>

                 {/* 极端温度监控 */}
                 <div className="glass-card p-6 rounded-3xl group border-t-4 border-t-rose-400 hover:-translate-y-1 transition-transform">
                   <div className="flex justify-between items-start mb-4">
                     <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center">
                       <ThermometerSun />
                     </div>
                     <span className="bg-rose-50 text-rose-600 text-xs font-bold px-2 py-1 rounded-lg">I2C via Hub</span>
                   </div>
                   <h3 className="text-lg font-bold text-slate-800 mb-2">ENV.III Climate</h3>
                   <p className="text-sm text-slate-500 mb-4 h-16">Monitors thermal stress. Temps &gt; 28°C or &lt; 16°C activate the built-in buzzer for immediate physical discomfort alerting.</p>
                 </div>

              </div>
            </motion.div>

            {/* 3. 多通道反馈日志面板 */}
             <motion.div variants={itemVariants} className="glass-card p-8 rounded-3xl mb-12 bg-gradient-to-r from-teal-50/40 to-emerald-50/40">
               <div className="flex justify-between items-center mb-8">
                  <h3 className="text-xl font-bold text-slate-800">Multimodal Feedback System</h3>
                  <div className="flex items-center gap-2 bg-slate-100 px-3 py-1 rounded-full border border-slate-200">
                     <BellRing className="text-slate-500 w-4 h-4" />
                     <span className="text-xs font-bold text-slate-600">Action History</span>
                  </div>
               </div>
               
               <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                 <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
                   <div className="text-rose-500 font-bold mb-1">Visual (LED Strip)</div>
                   <p className="text-xs text-slate-400 font-semibold uppercase mb-3">Red/Blue Flash</p>
                   <p className="text-2xl font-extrabold text-slate-800">4 <span className="text-sm text-slate-500 font-medium">times</span></p>
                 </div>
                 
                 <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
                   <div className="text-amber-500 font-bold mb-1">Haptic (Vibrator)</div>
                   <p className="text-xs text-slate-400 font-semibold uppercase mb-3">Silent Pulse</p>
                   <p className="text-2xl font-extrabold text-slate-800">12 <span className="text-sm text-slate-500 font-medium">times</span></p>
                 </div>
                 
                 <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
                   <div className="text-indigo-500 font-bold mb-1">Auditory (Buzzer)</div>
                   <p className="text-xs text-slate-400 font-semibold uppercase mb-3">Sharp Beep</p>
                   <p className="text-2xl font-extrabold text-slate-800">1 <span className="text-sm text-slate-500 font-medium">times</span></p>
                 </div>
               </div>
             </motion.div>

          </motion.div>
        )}

      </main>
    </div>
  );
}

/* --- 组件区 --- */
function NavTab({ children, active, onClick }) {
  return (
    <button onClick={onClick} className={`px-4 py-1.5 rounded-full text-sm font-semibold transition-all duration-300 ${active ? 'bg-white text-slate-800 shadow-sm' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-100/50'}`}>
      {children}
    </button>
  );
}

function KpiCard({ title, value, trend, trendUp, subtext, icon, bgGradient }) {
  return (
    <div className={`glass-card p-6 rounded-3xl relative overflow-hidden bg-gradient-to-br ${bgGradient} hover:-translate-y-1 transition-transform duration-300`}>
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-slate-500 text-sm font-bold tracking-wide uppercase">{title}</h3>
        <div className="p-2 bg-white rounded-xl shadow-sm border border-slate-100">{icon}</div>
      </div>
      <div className="flex items-end gap-3">
        <span className="text-4xl font-extrabold text-slate-800">{value}</span>
        <span className={`text-sm font-bold pb-1 ${trendUp ? 'text-emerald-500' : 'text-amber-500'}`}>{trend}</span>
      </div>
      <p className="text-xs text-slate-400 mt-2 font-medium">{subtext}</p>
    </div>
  );
}

// 专属硬件科普卡片
function HardwareCard({ unit, role, desc, icon, color }) {
  return (
    <div className={`p-5 rounded-2xl border bg-white/50 backdrop-blur-sm hover:shadow-md transition-shadow group`}>
      <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${color} border bg-opacity-30 group-hover:scale-110 transition-transform`}>
        {icon}
      </div>
      <h4 className="font-bold text-slate-800 text-sm mb-1">{unit}</h4>
      <p className="text-xs font-semibold text-blue-500 mb-2 uppercase tracking-wide">{role}</p>
      <p className="text-xs text-slate-500 leading-relaxed">{desc}</p>
    </div>
  );
}

function SensorRow({ name, val, status, color, bg }) {
  return (
    <div className="flex items-center justify-between p-3 rounded-2xl hover:bg-white/60 transition border border-transparent hover:border-slate-200">
      <div className="flex items-center gap-3">
        <div className={`w-2 h-2 rounded-full ${bg.replace('bg-', 'bg-').replace('100', '500')}`}></div>
        <div>
          <p className="text-sm font-bold text-slate-800">{name}</p>
          <p className="text-xs text-slate-500">{status}</p>
        </div>
      </div>
      <span className="font-bold text-slate-700">{val}</span>
    </div>
  );
}

function TimelineItem({ time, hardware, title, desc, type }) {
  const isSuccess = type === 'success';
  const isWarning = type === 'warning';
  return (
    <div className="flex gap-4">
      <div className="flex flex-col items-center">
        <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 shadow-sm border-2 border-white ${isSuccess ? 'bg-emerald-100 text-emerald-600' : isWarning ? 'bg-amber-100 text-amber-600' : 'bg-sky-100 text-sky-600'}`}>
          {isSuccess ? <CheckCircle2 size={16}/> : isWarning ? <AlertTriangle size={16}/> : <Fingerprint size={16}/>}
        </div>
        <div className="w-0.5 h-full bg-slate-200 mt-2 rounded-full"></div>
      </div>
      <div className="pb-6 pt-1">
        <div className="flex items-center gap-3 mb-1">
          <h4 className="text-sm font-bold text-slate-800">{title}</h4>
          <span className="text-xs font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full border border-slate-200">{hardware}</span>
        </div>
        <p className="text-xs text-slate-400 mb-1">{time}</p>
        <p className="text-sm text-slate-600 leading-relaxed max-w-2xl">{desc}</p>
      </div>
    </div>
  );
}